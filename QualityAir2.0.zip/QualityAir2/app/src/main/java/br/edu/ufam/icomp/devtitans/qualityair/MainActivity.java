package br.edu.ufam.icomp.devtitans.qualityair;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.Intent;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void abrirSensor1Activity(View v){
        Intent intent = new Intent(this, ActivitySensor1.class);
        startActivity(intent);
    }

    public void abrirSensor2Activity(View v){
        Intent intent = new Intent(this, ActivitySensor2.class);
        startActivity(intent);
    }

    public void abrirSensor3Activity(View v){
        Intent intent = new Intent(this, ActivitySensor3.class);
        startActivity(intent);
    }
}