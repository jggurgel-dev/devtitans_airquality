package br.edu.ufam.icomp.devtitans.qualityair;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;

public class ActivitySensor3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensor3);
    }

    public static int gerarNumeroAleatorio() {
        // Crie uma instância da classe Random
        Random random = new Random();

        // Gere um número aleatório entre 0 (inclusive) e 100 (exclusive)
        int numeroAleatorio = random.nextInt(101);

        return numeroAleatorio;
    }

    public void medirUmidade(View v){
        int val = gerarNumeroAleatorio();
        TextView myTextView = findViewById(R.id.textview_valor_s3);
        TextView myStatusText = findViewById(R.id.statusresid3);
        TextView textDescr = findViewById(R.id.descr_val_s3);
        ImageView imageView = findViewById(R.id.ring_s);
        myTextView.setText(String.valueOf(val));
        if(val<=30){
            textDescr.setText(R.string.dht0a30);
            imageView.setImageResource(R.drawable.ring_r);
            myStatusText.setText(R.string.statusruim);
        }
        else if (val > 30 && val <= 50) {
            textDescr.setText(R.string.dht30a50);
            imageView.setImageResource(R.drawable.ring_g);
            myStatusText.setText(R.string.statusbom);
        }
        else if (val > 50 && val <= 70) {
            textDescr.setText(R.string.dht50a70);
            imageView.setImageResource(R.drawable.ring_o);
            myStatusText.setText(R.string.statusmoderado);
        }
        else {
            textDescr.setText(R.string.dht70mais);
            imageView.setImageResource(R.drawable.ring_r);
            myStatusText.setText(R.string.statusmuitoruim);
        }
    }
}