package br.edu.ufam.icomp.devtitans.qualityair;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;

public class ActivitySensor2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensor2);
    }

    public static int gerarNumeroAleatorio() {
        // Crie uma instância da classe Random
        Random random = new Random();

        // Gere um número aleatório entre 0 (inclusive) e 100 (exclusive)
        int numeroAleatorio = 300+random.nextInt(9701);

        return numeroAleatorio;
    }

    public void medirglp(View v){
        int val = gerarNumeroAleatorio();
        TextView myTextView = findViewById(R.id.textview_valor_s2);
        TextView myStatusText = findViewById(R.id.statusresid2);
        TextView textDescr = findViewById(R.id.descr_val_s2);
        ImageView imageView = findViewById(R.id.ring_s2);
        myTextView.setText(String.valueOf(val));
        if(val<=700){
            textDescr.setText(R.string.mq300a700);
            imageView.setImageResource(R.drawable.ring_g);
            myStatusText.setText(R.string.baixoRisco);
        }
        else if (val > 700 && val <= 1000) {
            textDescr.setText(R.string.mq700a1000);
            imageView.setImageResource(R.drawable.ring_o);
            myStatusText.setText(R.string.moderadoRisco);
        }
        else {
            textDescr.setText(R.string.mq1000a10000);
            imageView.setImageResource(R.drawable.ring_r);
            myStatusText.setText(R.string.altoRisco);
        }
    }
}