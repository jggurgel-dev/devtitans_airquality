package br.edu.ufam.icomp.devtitans.qualityair;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;

public class ActivitySensor1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensor1);
    }

    public static int gerarNumeroAleatorio() {
        // Crie uma instância da classe Random
        Random random = new Random();

        // Gere um número aleatório entre 0 (inclusive) e 100 (exclusive)
        return random.nextInt(301);

    }

    public void medirpm10(View v){
        int val = gerarNumeroAleatorio();
        TextView myTextView = findViewById(R.id.textview_valor_s2);
        TextView myStatusText = findViewById(R.id.statusresid);
        TextView textDescr = findViewById(R.id.descr_val_s1);
        ImageView imageView = findViewById(R.id.ring_s1);
        myTextView.setText(String.valueOf(val));
        if(val<=50){
            textDescr.setText(R.string.pmde0a50);
            imageView.setImageResource(R.drawable.ring_g);
            myStatusText.setText(R.string.statusbom);
        }
        else if (val > 50 && val <= 100) {
            textDescr.setText(R.string.pmde51a100);
            imageView.setImageResource(R.drawable.ring_y);
            myStatusText.setText(R.string.statusmoderado);
        }
        else if (val > 100 && val <= 150) {
            textDescr.setText(R.string.pme101a150);
            imageView.setImageResource(R.drawable.ring_o);
            myStatusText.setText(R.string.statusruim);
        }
        else if (val > 150 && val <= 250) {
            textDescr.setText(R.string.pmde150a250);
            imageView.setImageResource(R.drawable.ring_r);
            myStatusText.setText(R.string.statusmuitoruim);
        }
        else {
            textDescr.setText(R.string.pmde250mais);
            imageView.setImageResource(R.drawable.ring_p);
            myStatusText.setText(R.string.statuspessimo);
        }
    }
    public void medirpm25(View v){
        int val = gerarNumeroAleatorio();
        TextView myTextView = findViewById(R.id.textview_valor_s2);
        TextView myStatusText = findViewById(R.id.statusresid);
        TextView textDescr = findViewById(R.id.descr_val_s1);
        ImageView imageView = findViewById(R.id.ring_s1);
        myTextView.setText(String.valueOf(val));
        if(val<=25){
            textDescr.setText(R.string.pmde0a50);
            imageView.setImageResource(R.drawable.ring_g);
            myStatusText.setText(R.string.statusbom);
        }
        else if (val > 25 && val <= 50) {
            textDescr.setText(R.string.pmde51a100);
            imageView.setImageResource(R.drawable.ring_y);
            myStatusText.setText(R.string.statusmoderado);
        }
        else if (val > 50 && val <= 75) {
            textDescr.setText(R.string.pme101a150);
            imageView.setImageResource(R.drawable.ring_o);
            myStatusText.setText(R.string.statusruim);
        }
        else if (val > 75 && val <= 125) {
            textDescr.setText(R.string.pmde150a250);
            imageView.setImageResource(R.drawable.ring_r);
            myStatusText.setText(R.string.statusmuitoruim);
        }
        else {
            textDescr.setText(R.string.pmde250mais);
            imageView.setImageResource(R.drawable.ring_p);
            myStatusText.setText(R.string.statuspessimo);
        }
    }
}